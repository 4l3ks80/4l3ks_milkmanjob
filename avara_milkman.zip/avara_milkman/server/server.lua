ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
TriggerEvent('esx_society:registerSociety', 'milkman', 'Milk Man', 'society_milkman', 'society_milkman', 'society_milkman', {type = 'public'})

RegisterServerEvent('milkman:pay')
AddEventHandler('milkman:pay', function(count)
    local xPlayer = ESX.GetPlayerFromId(source)
    local jobReward = math.random(35000, 45000)
    local item = xPlayer.getInventoryItem('milk_in_pail').count

    TriggerEvent('esx_addonaccount:getSharedAccount', 'society_milkman', function(account)
		societyAccount = account
	end)

    if item > 0 then
        xPlayer.removeInventoryItem('milk_in_pail', 10)
        xPlayer.addAccountMoney('money', jobReward)
        TriggerClientEvent('esx:showNotification', '~o~Otrzymujesz wypłatę '..jobReward..'$!')
        societyAccount.addMoney(jobReward / 2)
    else
        TriggerClientEvent('esx:showNotification', '~r~Nie posiadasz mleka')
    end
end)

RegisterServerEvent('milkman:CollectMilk')
AddEventHandler('milkman:CollectMilk', function()
    local xPlayer = ESX.GetPlayerFromId(source)
    xPlayer.addInventoryItem('milk_in_pail', 1)
end)