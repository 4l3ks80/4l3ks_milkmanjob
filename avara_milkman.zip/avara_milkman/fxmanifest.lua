fx_version 'bodacious'
game 'gta5'

shared_script '@Exile-Handler/shared/shared.lua'

client_script 'client/client.lua'

server_script 'server/server.lua'